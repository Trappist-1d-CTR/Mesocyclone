1. After downloading the zip file, extract it to whichever folder you prefer.
2. Once extracted, open the folder.
3. Then double-click on the .exe file to run the game. If it doesn’t work, try right-clicking and selecting “Run as administrator”.
4. Optionally, you can also right-click on the .exe file and, either right away or in “other options”, create a shortcut to move to the Desktop for easy access.
5. To reset the game, press ‘Shift + F’. To close it, press ‘Alt + f4’. If the former doesn’t work, try ‘Alt + fn + f4’. As last resort, you can forcefully terminate the game through the task manager, which you can access through ‘Ctrl + Alt + canc’.

! Game contains flight mechanics that can be difficult to learn. Please consult the Intructions Manual from GitHub's release: https://github.com/Trappist-1d-CTR/Mesocyclone