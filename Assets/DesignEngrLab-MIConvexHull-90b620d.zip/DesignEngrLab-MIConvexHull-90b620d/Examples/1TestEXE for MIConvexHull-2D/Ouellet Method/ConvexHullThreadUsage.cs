﻿
namespace OuelletConvexHull
{
	public enum ConvexHullThreadUsage
	{
		AutoSelect = 0,
		OnlyOne = 1,
		All = 2,
		FixedFour = 4,
		OneOrFour = 8
	}
}
		// ******************************************************************
