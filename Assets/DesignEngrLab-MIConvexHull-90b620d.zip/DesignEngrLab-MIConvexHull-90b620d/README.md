# MIConvexHull
A .Net fast convex hull library for 2, 3, and higher dimensions
http://designengrlab.github.io/MIConvexHull/
